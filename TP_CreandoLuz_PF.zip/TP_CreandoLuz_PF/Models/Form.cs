using System;
namespace TP_CreandoLuz_PF.Models{
    public class Form {
        public string? Nombre {get; set;}
        public string? Apellido {get; set;}
        public int? Telefono {get; set;}
        public string? Mail {get; set;}
        public string? Cuerpo {get; set;}
    }
}