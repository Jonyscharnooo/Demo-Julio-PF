﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP_CreandoLuz_PF.Models;

namespace TP_CreandoLuz_PF.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string email, string password)
    {
        Usuario usuario = BD.ObtenerUsuarioPorEmail(email);

        if (usuario != null && usuario.Password == password)
        {
            // Usuario autenticado, puedes establecer la sesión u otras acciones
            return RedirectToAction("Index", "Home");
        }

        // Usuario no autenticado, manejar de acuerdo a tus necesidades
        return View();
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(Usuario usuario)
    {
        bool registrado = BD.RegistrarUsuario(usuario);

        if (registrado)
        {
            // Usuario registrado correctamente, puedes realizar acciones adicionales
            return RedirectToAction("Index", "Home");
        }

        // Fallo al registrar el usuario, manejar de acuerdo a tus necesidades
        return View();
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Form(){
        return View();
    }
    
    public IActionResult Agradecer()
    {
        return View();
    }

    public IActionResult signIn(){
        return View();
    }
    
    public IActionResult formDonar(){
        return View();
    }

    public IActionResult Guardar(Form Frm){
        BD.MandarForm(Frm);
        return RedirectToAction("Agradecer");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}