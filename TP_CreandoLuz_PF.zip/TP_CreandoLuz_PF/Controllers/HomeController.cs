﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP_CreandoLuz_PF.Models;
using TP_CreandoLuz_PF.Permisos;
using Microsoft.AspNetCore.Http;

namespace TP_CreandoLuz_PF.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Form(){
        return View();
    }
    
    public IActionResult Agradecer()
    {
        return View();
    }

    public IActionResult signIn(){
        return View();
    }
    
    public IActionResult formDonar(){
        return View();
    }

    public IActionResult Guardar(Form Frm){
        BD.MandarForm(Frm);
        return RedirectToAction("Agradecer");
    }

    public ActionResult CerrarSesion()
        {
            HttpContext.Session.SetString("usuario", null);
            return RedirectToAction("Login", "Acceso");
        }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}